#
# cluster - Vector Quantization / Kmeans
#

from info import __doc__

__all__ = ['vq']

import vq
from numpy.testing import NumpyTest
test = NumpyTest().test
