#!/usr/bin/env python
#
# Created by: Pearu Peterson, October 2003
#

import sys
from numpy.testing import *
set_package_path()
import linalg.atlas_version
restore_path()

# No futher tests possible.
# Importing atlas_version will print out atlas version.
